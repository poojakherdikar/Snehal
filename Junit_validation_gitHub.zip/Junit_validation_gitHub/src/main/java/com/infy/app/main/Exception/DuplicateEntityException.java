package com.infy.app.main.Exception;

public class DuplicateEntityException extends RuntimeException{

	public DuplicateEntityException(String msg) {
		super(msg);
	}

	public DuplicateEntityException() {
		// TODO Auto-generated constructor stub
	}
	
	
}
