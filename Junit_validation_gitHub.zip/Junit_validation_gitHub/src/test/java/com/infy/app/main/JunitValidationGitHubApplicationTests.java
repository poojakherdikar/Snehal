package com.infy.app.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitValidationGitHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
